exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Hello from my node Lambda updated succesfully.');
};